function Skills() {
  const skillCategories = [
    {
      title: "Frontend",
      skills: ["HTML5", "CSS3", "JavaScript", "React Js", "Tailwind CSS"]
    },
    {
      title: "WordPress",
      skills: ["WooCommerce", "ACF", "Elementor", "Gutenberg"]
    },
    {
      title: "Backend",
      skills: ["PHP", "MySQL", "Rest API"]
    },
    {
      title: "Others",
      skills: ["Git", "GitHub", "Netlify", "VS Code", "cPanel", "Sublime", "Figma"]
    }
  ]

  return (
    <section id="skills" className="skills">
      <div className="container">
        <div className="section-header animate-on-scroll">
          <h2 className="section-title">Skills</h2>
          <p className="section-description">
            Here are the skills I've been building and polishing for the last some years, learning, experimenting, and delivering real projects.
          </p>
        </div>
        
        <div className="skills-grid">
          {skillCategories.map((category, index) => (
            <div key={index} className="skill-category animate-on-scroll">
              <h3 className="skill-category-title">{category.title}</h3>
              <ul className="skill-list">
                {category.skills.map((skill, skillIndex) => (
                  <li key={skillIndex} className="skill-item">{skill}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Skills