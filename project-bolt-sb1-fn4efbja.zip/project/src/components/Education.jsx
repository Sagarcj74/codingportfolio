function Education() {
  const educationData = [
    {
      institution: "Your School Name",
      degree: "10th Grade",
      duration: "Year - Year"
    },
    {
      institution: "Your College Name",
      degree: "12th Grade / Diploma",
      duration: "Year - Year"
    },
    {
      institution: "Your University Name",
      degree: "Bachelor's Degree",
      duration: "Year - Year"
    },
    {
      institution: "Additional Certification",
      degree: "Course/Certification Name",
      duration: "Year - Year"
    }
  ]

  return (
    <section id="education" className="education">
      <div className="container">
        <div className="section-header animate-on-scroll">
          <h2 className="section-title">Education</h2>
          <p className="section-description">
            My education has been a journey of self-discovery and growth. My educational details are as follows.
          </p>
        </div>
        
        <div className="education-grid">
          {educationData.map((edu, index) => (
            <div key={index} className="education-item animate-on-scroll">
              <h3 className="education-institution">{edu.institution}</h3>
              <h4 className="education-degree">{edu.degree}</h4>
              <p className="education-duration">{edu.duration}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Education