function Experience() {
  const experiences = [
    {
      title: "Data Analyst Intern",
      company: "Rajneethi Political Consultant",
      duration: "3-month internship",
      type: "Internship"
    },
    {
      title: "Web Developer",
      company: "Skeltron Info Solutions",
      duration: "August 2024 to May 2025",
      type: "Full-time"
    },
    {
      title: "Web Developer",
      company: "Influencio Ads Private Limited",
      duration: "June 2025 to Present",
      type: "Full-time"
    }
  ]

  return (
    <section id="experience" className="experience">
      <div className="container">
        <div className="section-header animate-on-scroll">
          <h2 className="section-title">Experience</h2>
          <p className="section-description">
            Worked with multiple companies and internships, learning and growing along the way.
          </p>
        </div>
        
        <div className="experience-timeline">
          {experiences.map((exp, index) => (
            <div key={index} className="experience-item animate-on-scroll">
              <div className="experience-content">
                <div className="experience-header">
                  <h3 className="experience-title">{exp.title}</h3>
                  <span className="experience-type">{exp.type}</span>
                </div>
                <h4 className="experience-company">{exp.company}</h4>
                <p className="experience-duration">{exp.duration}</p>
              </div>
              <div className="experience-marker"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Experience