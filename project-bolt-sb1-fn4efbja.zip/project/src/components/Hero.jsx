import ProfileCard from './ProfileCard'
import Particles from './Particles'

function Hero() {
  const handleContactClick = () => {
    const contactSection = document.getElementById('contact')
    if (contactSection) {
      const headerOffset = 80
      const elementPosition = contactSection.offsetTop
      const offsetPosition = elementPosition - headerOffset

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      })
    }
  }

  return (
    <section id="about" className="hero">
      {/* Animated Particles Background */}
      <div className="hero-background">
        <Particles
          particleColors={['#ffffff', '#e100ff', '#8c00ff']}
          particleCount={150}
          particleSpread={8}
          speed={0.05}
          particleBaseSize={80}
          moveParticlesOnHover={true}
          alphaParticles={true}
          disableRotation={false}
          particleHoverFactor={0.5}
          sizeRandomness={0.8}
          cameraDistance={25}
        />
      </div>
      
      <div className="container">
        <div className="hero-content animate-on-scroll">
          <div className="hero-text">
            <h1 className="hero-title">
              <span className="hero-greeting">Hi, I am</span>
              <span className="hero-name">Sagar C J</span>
              <span className="hero-role">I am a WordPress Developer</span>
            </h1>
            
            <p className="hero-description">
              I'm a web developer with 2 years of solid industry experience turning ideas into websites and web apps that not only look good but work seamlessly. From handling clients to delivering projects end-to-end, I've learned how to get things done, clean, responsive, and on time. I'm all about learning, growing, and making sure whatever I build adds real value.
            </p>
            
            <button className="btn btn-primary btn-large">
              Check Resume
            </button>
          </div>
          
          <div className="hero-image">
            <ProfileCard
              name="Sagar C J"
              title="WordPress Developer"
              handle="sagarcj"
              status="Available for Work"
              contactText="Contact Me"
              avatarUrl="https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=400"
              showUserInfo={true}
              enableTilt={true}
              onContactClick={handleContactClick}
            />
          </div>
        </div>
      </div>
    </section>
  )
}

export default Hero