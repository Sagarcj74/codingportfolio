import { useState } from 'react'

function Header({ activeSection }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId)
    if (element) {
      const headerOffset = 80
      const elementPosition = element.offsetTop
      const offsetPosition = elementPosition - headerOffset

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      })
    }
    setIsMenuOpen(false)
  }

  return (
    <header className="header">
      <div className="container">
        <div className="header-content">
          <div className="logo">
            <span>Sagar C J</span>
          </div>
          
          <nav className={`nav ${isMenuOpen ? 'nav-open' : ''}`}>
            <ul className="nav-list">
              <li>
                <button 
                  className={`nav-link ${activeSection === 'about' ? 'active' : ''}`}
                  onClick={() => scrollToSection('about')}
                >
                  About
                </button>
              </li>
              <li>
                <button 
                  className={`nav-link ${activeSection === 'skills' ? 'active' : ''}`}
                  onClick={() => scrollToSection('skills')}
                >
                  Skills
                </button>
              </li>
              <li>
                <button 
                  className={`nav-link ${activeSection === 'experience' ? 'active' : ''}`}
                  onClick={() => scrollToSection('experience')}
                >
                  Experience
                </button>
              </li>
              <li>
                <button 
                  className={`nav-link ${activeSection === 'education' ? 'active' : ''}`}
                  onClick={() => scrollToSection('education')}
                >
                  Education
                </button>
              </li>
              <li>
                <button 
                  className={`nav-link ${activeSection === 'contact' ? 'active' : ''}`}
                  onClick={() => scrollToSection('contact')}
                >
                  Insights
                </button>
              </li>
            </ul>
          </nav>

          <button className="btn btn-primary">
            Call Now
          </button>

          <button 
            className="menu-toggle"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </div>
    </header>
  )
}

export default Header